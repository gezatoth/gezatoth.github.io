% example_maxppt   Example for the application of maxppt
%    This example computes the maximum for the operator Jx^2+Jy^2 
%    for states that are PPT with respect to some bipartition of the qubits.
%    Similar otimisation is carried out in http://arxiv.org/abs/0903.3910.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or1
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

echo on

% Looking for maximum for Jx^2+Jy^2 for states that are biseparable
% with respect to some bipartition of the qubits

% Number of quibits 
N=4;

% Define Pauli spin matrices x,y,z and e
paulixyz;

% Define the collective angular momentum components
Jx=coll(x,N)/2;
Jy=coll(y,N)/2;
Jz=coll(z,N)/2;

% Define the operator for which we look for the maximum
M=Jx^2+Jy^2;

% Maximum for the 1:234 partition
max1=maxppt(M,1)

% Maximum for the 12:34 partition
max12=maxppt(M,1:2)

echo off

