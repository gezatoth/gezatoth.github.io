% su2   SU(2) generators for dxd matrices
%   [Jx,Jy,Jz]=su2(d) gives three generators of the SU(2)
%   group for dxd matrices.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function [Jx,Jy,Jz]=su2(d);

N=d-1;
a1da1=diag([0:N]);
a2da2=diag([N-(0:N)]);
a1da2=zeros(N+1,N+1);
for k=0:N-1
    a1da2(k+1+1,k+1)=sqrt((k+1)*(N-k));   
end %for
a2da1=a1da2';

% Schwinger's construction
Jz=(a1da1-a2da2)/2;
Jx=(a1da2+a2da1)/2;
Jy=-i*(a1da2-a2da1)/2;
