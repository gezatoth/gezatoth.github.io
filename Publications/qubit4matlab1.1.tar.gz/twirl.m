% twirl   Twirling
%   twirl(rho) twirls the density matrix rho.
%   [rho,difference]=twirl(rho) also gives the 
%   difference between the original and the 
%   twirled state. Here the difference is zero
%   for Werner states.
%   The Nit variable in the beginning of the program
%   can be set to determine how many random
%   unitaries must be used for twirling.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function [U0,difference]=twirl(rho);

% Number of random unitaries used
Nit=100;

x=[0 1;1 0];
z=[1 0;0 -1];
y=i*x*z;

[sy,sx]=size(rho);
N=log2(sx);

difference=0;
U0=0;
for n=0:Nit
    phi=rand(1,1)*4*pi;
    theta=rand(1,1)*4*pi;
    U=expm(i*phi*x)*expm(i*theta*z);
    UU=U;
    for n=2:N
        UU=kron(UU,U);   
    end %for
    r=UU'*rho*UU;
    delta=r-rho;
    if difference<real(trace(delta*delta')),
      U0=U;
      difference=real(trace(delta*delta'));
    end %if
end %for


