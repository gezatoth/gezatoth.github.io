% decompose   Creates a string with the Pauli decomposition of a
%    Hermitian matrix. 
%    Form of use: decompose(rho) where rho is the density matrix.
%    One can print in LaTeX format with decompose(rho,1).
%    For the numbering of qubits we note that mkron(x,y,z) is
%    decomposed into "zyx" or "Z^{(1)}Y^{(2)}X^{(3)}".

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function pstring=decompose(rho,varargin)

% Corraltions smaller than that are taken to be zero
mincorr=1e-14;

LaTeXON=0;
if ~isempty(varargin),
   if varargin{1}==1,
       LaTeXON=1;
   end %if
end %if
x=[0 1;1 0];
z=[1 0;0 -1];
y=i*x*z;

% rho=ketbra2(rho);
  
[sy,sx]=size(rho);

N=log2(sx);

pstring='';

OPstr='1xyz';
OPstr2='EXYZ';

OP={eye(2),x,y,z};

for n=4^N+0:4^N+4^N-1
    indexstr=dec2base(n,4);
    indexstr=indexstr(2:end);
    op=1;
    for m=1:length(indexstr);
        opindex=str2num(indexstr(length(indexstr)+1-m))+1;
        op=kron(op,OP{opindex});        
    end %for
    corr=trace(rho*op)/2^N;
    % Make it real
    corr=real(corr); 
    if abs(corr)>0,
       termstr='';
       % Contruct string for the term
       if LaTeXON,
          if n==4^N,
              termstr='E';
          else
             for m=1:length(indexstr);
                opindex=str2num(indexstr(m))+1;
                if opindex >1,                 
                   termstr=[termstr,OPstr2(opindex) '^{(' num2str(m) ')}' ];  
               end %if
             end %for
              
          end %if
       else
          for m=1:length(indexstr);
              opindex=str2num(indexstr(m))+1;
              termstr=[termstr,OPstr(opindex)];        
          end %for
       end %if
       if isempty(pstring),
           if abs(corr-1)<mincorr,  
              pstring=[termstr];
           elseif abs(corr+1)<mincorr,
              pstring=['-' termstr];
           elseif abs(corr)>mincorr,
              pstring=[num2str(corr) '*' termstr];
           end %if
       else
           if corr>mincorr,
             if abs(corr-1)<mincorr,
                 pstring=[pstring '+' termstr];
             else
                 pstring=[pstring '+' num2str(corr) '*' termstr];
             end %if
          elseif corr<-mincorr,
             if abs(corr+1)<mincorr,
                 pstring=[pstring '-' termstr];
             else
                 pstring=[pstring '-' num2str(abs(corr)) '*' termstr];
             end %if
          end %if             
       end %if
    end %if
end %for

if isempty(pstring),
   pstring='0';
end %if
