% printv   Prints a state vector in product basis.
%   printv(s) gives a string describing the statevector
%   s as a linear combination of elements of the product basis.
%   The bound above which an element of the state vector
%   is considered 0 is defined in the variable vmin of the 
%   printv.m file.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.


function s=printv(v);

% Treshold
vmin=1e-4;

index=find(abs(v)>vmin);

N=log2(length(v));

s='';
for n=1:length(index)
   ii=index(n);
   vv=v(ii);
   b=dec2bin(2^N+ii-1);
   b=b(2:end);
   if isempty(s),
      if vv==1,
         s=['|' b '>'];,
      elseif vv==-1,
         s=[ '-|' b '>'];,
      elseif vv>0,
	 s=[ num2str(vv) '|' b '>'  ];
      else 
	 s=[ '-' num2str(abs(vv)) '|' b '>'  ];
      end %if
   else
      if vv==1,
         s=[s '+|' b '>'];,
      elseif vv==-1,
         s=[s '-|' b '>'];,
      elseif vv>0,
	 s=[ s '+' num2str(vv) '|' b '>'  ];
      else 
	 s=[ s '-' num2str(abs(vv)) '|' b '>'  ];
      end %if
   end %if
end %for

