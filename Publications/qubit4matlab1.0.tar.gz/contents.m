% MATLAB routines for quantum mechanics.
% 
% General
%  contents             - List of commands
%  ver                  - Version
%
% Simple commands for efficent coding of QM in MATLAB
%  qvec                 - Empty statevector for given number of qubits
%  qsize                - Size of state vector or density matrix in qubits
%  qeye                 - Identiy matrix for given number of qubits
%  ket                  - Creating a normalized column vector
%  ketbra               - Creating a projector from a vector
%  ketbra2              - Creating a projector from the argument if the argument is
%                         a vector.
%  nm                   - Normalization
%  trace2               - Trace-square of a matrix
%  paulixyz             - Define pauli matrices x,y,z and e=eye(2)
%  su3                  - Define the SU(3) generators m1,...,m8 and ee=eye(3)
%  su3_alternative      - Define alternative SU(3) generators m1,...,m8 and ee=eye(3);        
%
% Interesting quantum states
%  ghzstate             - Green-Horne-Zelinger state
%  cstate               - Cluster state
%  rstate               - Ring cluster state
%  gstate               - Graph state
%  gstate_stabilizer    - Stabilizer of a graph state
%  wstate               - W state
%  dstate               - Dicke state
%  singlet              - Singlet state
%  mmstate              - Denisty matrix for the maximally mixed state
%
% Operations useful in quantum information
%  mkron                - Kronecker product with several arguments
%  pkron                - Repetation of the Kronecker product given times
%  pt                   - Partial transpose for a qubit register
%  reorder              - Reorder the qudits
%  reorder_mat          - The operators corresponding to reordering a
%                         register of qudits
%  remove               - Reduced density matrix in a qudit register
%  keep                 - Reduced density matrix in a qubit register
%  mqubitop             - Quantum operation acting on given qubits
%  spmqubitop           - mqubitop with sparse matrices
%  comm                 - Commutator
%  nnchain              - Nearest-neighbor spin chain Hamiltonian
%  nnchainp             - Spin chain Hamiltonian with periodic boundary
%                         condition
%  printv               - Print statevector in product basis
%
% Spin chains
%  ising_ground         - Ground state energy of Ising model
%  ising_free           - Free energy in thermal state
%  ising_thermal        - Internal energy in thermal state
%
% Formatted input/output
%  decompose            - Display pauli decomposition of matrix
%  paulistr             - Convert symbolic string to operator 
%
% Maximum for separable/biseparable states and Schmidt decomposition
%  schmidt              - Schmuidt coeffcients for a pure state
%  maxsep               - Maximum of an operator for separable states
%  maxsymsep            - The same us maxsep but for
%                         permutationally invariant sep. states
%  maxbisep             - Maximum of an operator for separable states
%  maxb                 - Like maxbisep, but for all bipartitoning
%  overlapb             - Maximum overlap of pure state with bisep. states
%
% Symmetries and Werner states
%  twirl                - Twirling
%  twirl2               - How close is a state to Werner states

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.


