QUBIT : MATLAB PACKAGE BY GEZA TOTH

FOR QUANTUM INFORMATION/QUANTUM MECHANICS

This program package helps modeling spin chains, 
qubit registers, etc. according to nonrelativistic 
quantum mechanics and some novel ideas from quantum 
information theory.

In particular, it contains MATLAB routines
for reordering qubits, for computing
the reduced density matrix after removing
some of the qubits, for partial transposition, etc.
Most of the routines work also for qudits.
It also has routines for handling GHZ states, 
cluster states, graph states, dicke states, etc.

For the list of functions write

         help contents

---------------

History of versions:

QM versions: 

V1.0         12 Apr  2005

V1.1         14 June 2005

keep/remove: bug corrected
new functions for qudits
new functions for spin chains

Name changed to QUBIT4MATLAB:

QUBIT4MATLAB V1.0   1 Sept 2005
nm:          bug corrected
