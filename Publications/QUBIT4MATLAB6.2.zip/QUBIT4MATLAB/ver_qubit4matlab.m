% ver   Prints out version.

disp(['MATLAB routines for Quantum Mechanics QUBIT4MATLAB V 6.2'])
disp(['Geza Toth, 2005-2023'])
