% reduced_sym   N-qubit reduced density matrix of a symmetric state.
%               reduced_sym(rhos,N) gives the reduced state as a
%               symmertic state stored in an NxN matrix.

function rhos_red=reduced_sym(rhos,N);

% Number of qubits
[sy,sx]=size(rhos);
M=sy-1;

% Computing the reduced matrix of rho prime
% It is an N-qubit symmetric state
summa=0*rhos(1:N+1,1:N+1); % Works also if rhos is symbolic or sdpvar
for k=0:M
    
    % l<k and l>k
    for l=[0:k-1,k+1:M]
        Mat=zeros(N+1,N+1);
        for n=max(0,k-(M-N)):min(k,N)
            np=n+(l-k);
            if np>=0 && N>=np && M-N>=l-np
               Mat(n+1,np+1)=Mat(n+1,np+1)+sqrt(binom(N,n)*binom(N,np)*binom(M-N,k-n)*binom(M-N,l-np));              
            end %if
        end %for
        summa=summa+rhos(k+1,l+1)*Mat/sqrt(binom(M,k)*binom(M,l));
    end %for
   
    % l=k
    Mat=zeros(N+1,N+1);
    for n=max(0,k-(M-N)):min(k,N)
        Mat(n+1,n+1)=Mat(n+1,n+1)+binom(N,n)*binom(M-N,k-n);
    end %for
    summa=summa+rhos(k+1,k+1)*Mat/binom(M,k);
    
end %for
rhos_red=summa;

