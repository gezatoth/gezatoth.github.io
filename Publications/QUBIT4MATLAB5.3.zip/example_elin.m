% Convex roof of the linear entropy - example

% The result is 0.065191337232140 

tic

rho=BES_UPB3x3;

rank_rho=rank(rho)

E_lin=elin(rho)

toc


