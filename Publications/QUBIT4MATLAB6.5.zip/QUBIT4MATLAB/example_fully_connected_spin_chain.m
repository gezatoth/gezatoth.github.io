% example_fully_connected_spin_chain   Example for using 
%    optspinsq and optsudsq. It reproduces Tables 2,3 in
%    https://arxiv.org/abs/2406.13338
%
% Table 2: Maximal temperatures until which thermal states of the model 
% given in Eq. (127) for N = 6 and d = 3
% are detected with optimal su(3)-squeezing and 
% optimal spin squeezing respectively.
%
% Table 3: Maximal temperatures until which thermal states of the model 
% given in Eq. (128) for N = 6 and d = 3
% are detected with optimal su(3)-squeezing and 
% optimal spin squeezing respectively.

clear all
close all
format compact

%%%%%%% INPUT PARAMETERS %%%%

% Set number of particles
N=6;

% Set Hamiltonian
% Type 1: H=-(1/N)*(Jx^2+Jy^2+gamma_const*Jz^2); % Eq. (127)
% Type 2: H=(1/N)*(Jx^2+Jy^2+gamma_const*Jz^2);  % Eq. (128)
TypeOfHamiltonian=1;

% Set parameter gamma
gamma_const=0;

% Set initial lower and upper bound
TL0=0;
TH0=12;

% Set resolution
DeltaT0=0.00000001;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Particle dimension
d=3;

g=sud(d);
% Note: trace(g(:,:,1)*g(:,:,1))=2

% Hamiltonian
[jx,jy,jz]=su2(d);

Jx=coll(jx,N);
Jy=coll(jy,N);
Jz=coll(jz,N);

% Choose Hamiltonian

switch TypeOfHamiltonian
    case 1, H=-(1/N)*(Jx^2+Jy^2+gamma_const*Jz^2);
    case 2, H=+(1/N)*(Jx^2+Jy^2+gamma_const*Jz^2);
end

%%%%%%%% SU(d) criterion %%%%%%

TL=TL0;
TH=TH0;
DeltaT=DeltaT0;

while (TH-TL)>DeltaT,
    
    T=(TH+TL)/2;
    
    rho=thstate(H,T);
    
    criterion_with_variances=optsudsq(rho,d);
    
    if criterion_with_variances<0
        TL=T;
    else
        TH=T;
    end
        
end

% Print out the result 1
temperature_sud=(TH+TL)/2

%%%%%% SU(2) criterion %%%%%%

TL=TL0;
TH=TH0;
DeltaT=DeltaT0;

[jx,jy,jz]=su2(d);

Jx=coll(jx,N);
Jy=coll(jy,N);
Jz=coll(jz,N);

while (TH-TL)>DeltaT,
    
    T=(TH+TL)/2;
    
    rho=thstate(H,T);
    
    criterion_with_variances=optspinsq(rho,d);
    
    if criterion_with_variances<0
        TL=T;
    else
        TH=T;
    end
    
end

% Print out the result 2
temperature_spin=(TH+TL)/2

