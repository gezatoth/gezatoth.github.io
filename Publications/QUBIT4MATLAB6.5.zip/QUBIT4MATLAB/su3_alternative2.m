% su3_alternative2   Alternative generators of SU(3)
%   Generators of SU(3) in m1,m2,...,m8.
%   Normalization: Tr(m_k*m_l)=2*delta_{kl}.
%   The first three are the angular momentum coordinates
%

ee=eye(3);

[jx,jy,jz]=su2(3);

m1=jx;
m2=jy;
m3=jz;
m4=(jx*jy+jy*jx);
m5=(jy*jz+jz*jy);
m6=(jz*jx+jx*jz);
m7=(jx^2-jy^2);
m8=sqrt(3)*jz^2-2/sqrt(3)*eye(3,3);

% % Test
% C=zeros(8,8);
% mm={m1,m2,m3,m4,m5,m6,m7,m8};
% for n=1:8
%     for m=1:8
%         C(m,n)=trace(mm{n}*mm{m});
%     end %for
% end %for
% C
% 
% m=m1^2+m2^2+m3^2+m4^2+m5^2+m6^2+m7^2+m8^2