% optsudsq(rho)   Optimal su(d) squeezing inequalities
%    optsudsq(rho) gives back a negative value if the
%    multi-qubit state rho is detected as entangled
%    by the optimal su(d) squeezing inequalities.
%    The form [fmin,gm,U,Q,C]=optsudsq(rho) gives back
%    fmin, the,minimum, and the gamma, U, Q, C matrcies
%    (see the publiction below)
%    Beside the inequalities themselves, a method is also
%    implemented that looks for the optimal choice of 
%    su(d) generators.
%    optsudsq(rho,d) works for systems of qudits of dimension d.
%    [fmin,gm,U,Q,C]=optsudsq(rho) gives back also
%    the fmin,U,Q,C matrices.
%    See https://arxiv.org/abs/2406.13338

function [fmin,gm,U,Q,C]=optsudsq(rho,varargin)

if isempty(varargin),
    d=2;
else
    if length(varargin)~=1,
        error('Wrong number of input arguments.');
    end %if
    d=varargin{1};
end %if

j=(d-1)/2;

[sy,sx]=size(rho);
N=floor(log2(sx)/log2(d)+0.5);

g=sud(d);
% Note: trace(g(:,:,1)*g(:,:,1))=2

Gk=zeros(d^N,d^N,d^2-1);
sumvar=0;
for k=1:d^2-1
    gk=g(:,:,k);
    Gk(:,:,k)=coll(gk,N);
end

% Correlation matrix
C=zeros(d^2-1,d^2-1);
gm=zeros(d^2-1,d^2-1); % gamma
Q=zeros(d^2-1,d^2-1);
for k=1:d^2-1
    for l=1:d^2-1
        C(k,l)=ex(Gk(:,:,k)*Gk(:,:,l)+Gk(:,:,l)*Gk(:,:,k),rho)/2;
        gm(k,l)=C(k,l)-ex(Gk(:,:,k),rho)*ex(Gk(:,:,l),rho);
        Q_temp=0;
        for n=1:N
            Q_temp=Q_temp...
                +ex(quditop(g(:,:,k),n,N)*quditop(g(:,:,l),n,N)...
                   +quditop(g(:,:,l),n,N)*quditop(g(:,:,k),n,N),rho)/2;
        end
        Q(k,l)=Q_temp/N;
    end
end
Q0=2/d;
Q=Q-Q0*eye(d^2-1,d^2-1);

U=gm+C/(N-1)-N^2/(N-1)*(Q+Q0*eye(d^2-1,d^2-1));

eigU=eig(U);

fmin=trace(gm)-sum(eigU.*(eigU>0))-2*N*(d-1);
