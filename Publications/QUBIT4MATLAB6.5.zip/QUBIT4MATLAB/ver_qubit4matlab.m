% ver_qubit4matlab   Prints out version.

disp(['MATLAB routines for Quantum Mechanics QUBIT4MATLAB V 6.5'])
disp(['Geza Toth, 2005-2025'])
