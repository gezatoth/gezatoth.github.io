% swapfidelity   swapfidelity(rho,sigma)
% swapfidelity_ppt   swapfidelity(rho,sigma)_ppt defined as the maximum
%   of trace (Rho S), where S is the swap operator, and the
%   marginals of Rho are rho and sigma.
%   The optimization is over ppt states.
%
%   It could also be realized with wdistsquare_DPT_ppt.m 
%   or wdistsquare_GMPC_ppt.m with an appropriate choice 
%   of the Hn operators.
%
%   See
%   https://arxiv.org/abs/2102.07787

function [optimum,diagnostic,coupling]=swapfidelity_ppt(rho,sigma)

[sy,sx]=size(rho);

d=sx;
d1=d;
d2=d;

E1=eye(d1,d1);
E2=eye(d2,d2);

rho12=sdpvar(d1*d2,d1*d2,'hermitian','complex');
rhoA=keep_nonorm(rho12,1,d);
rhoB=keep_nonorm(rho12,2,d);
FF=[rhoA==rho]+[rhoB==sigma]+[rho12>=0]+[trace(rho12)==1];

FF=FF+[pt_nonorm(rho12,1,d)>=0];

C=reordermat([1 2],d);
ops = sdpsettings('solver','mosek','verbose',0,'debug',1);
diagnostic=solvesdp(FF,-real(trace(rho12*C)),ops);
optimum=double(real(trace(rho12*C)));

coupling=double(rho12);
