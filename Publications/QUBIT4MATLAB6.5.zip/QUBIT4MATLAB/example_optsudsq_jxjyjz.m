% example_optsudsq_jxjyjz   Example using optsudsq_jxjyjz 
%
% It reproduces Fig. 3 in
% https://arxiv.org/abs/2406.13338
%
% The diagonal elements Ukk for the thermal states of 
% (circle) the Hamiltonian given in Eq. (125) for T = 1, 
% (diamond) the Hamiltonian given in Eq. (127) for gamma = 1 and T = 0.5, and 
% (square) the Hamiltonian given in Eq. (128) for gamma = 0 and T = 0.5, 
% where N = 4 and d = 3. Note that we use the local su(d) generators
% given in Eq. (129), thus all these states have a diagonal U.

clear all
close all
format compact

% Dimension of particles
d=3;

% Particle number
N=4;

g=sud(d);
H=coll(g(:,:,1),N)^2;
for n=2:8
    H=H+coll(g(:,:,n),N)^2;
end
H=H/N;

T=1;
rho1=thstate(H,T);

[fmin1,gm1,U1,Q1]=optsudsq(rho1,d);
[fmin1b,gm1b,U1b,Q1b]=optsudsq_jxjyjz(rho1);

d=3;
% Hamiltonian
[jx,jy,jz]=su2(d);

Jx=coll(jx,N);
Jy=coll(jy,N);
Jz=coll(jz,N);

H=-Jx^2-Jy^2;
H=H/N;

T=0.5;
rho2=thstate(H,T);

[fmin2,gm2,U2,Q2]=optsudsq(rho2,d);
[fmin2b,gm2b,U2b,Q2b]=optsudsq_jxjyjz(rho2);

% Hamiltonian
[jx,jy,jz]=su2(d);

Jx=coll(jx,N);  
Jy=coll(jy,N);
Jz=coll(jz,N);

H=Jx^2+Jy^2+Jz^2;
H=H/N;

T=0.5;
rho3=thstate(H,T);

[fmin3,gm3,U3,Q3]=optsudsq(rho3,d);
% [fmin3b,gm3b,U3b,Q3b]=optsudsq_jxjyjz(rho3,d);
[fmin3b,gm3b,U3b,Q3b]=optsudsq_jxjyjz(rho3);

plot(1:8,diag(U1b),'o','MarkerFaceColor',[1 0 0],'MarkerEdgeColor',[1 0 0],'MarkerSize',12)
hold on
plot(1:8,diag(U3b),'d','MarkerFaceColor',[0 0 1],'MarkerEdgeColor',[0 0 1],'MarkerSize',12)
plot(1:8,diag(U2b),'s','MarkerFaceColor',[0 0 0],'MarkerEdgeColor',[0 0 0],'MarkerSize',12)
hold off

grid

set(gca,'LineWidth',2,'FontSize',22,'TickLabelInterpreter','latex')

xlabel('$k$','Interpreter','LaTeX','FontSize',32)
ylabel('$U_{kk}$','Interpreter','LaTeX','FontSize',32)

axis([1 8 -4 10])



