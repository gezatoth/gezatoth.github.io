% swapfidelity   swapfidelity(rho,sigma) defined as the maximum
%   of trace (Rho S), where S is the swap operator, and the
%   marginals of Rho are rho and sigma.
%   See
%   https://arxiv.org/abs/2102.07787

function [optimum,diagnostic,coupling]=swapfidelity(rho,sigma)

[sy,sx]=size(rho);

d=sx;
d1=d;
d2=d;

E1=eye(d1,d1);
E2=eye(d2,d2);

rho12=sdpvar(d1*d2,d1*d2,'hermitian','complex');
rhoA=keep_nonorm(rho12,1,d);
rhoB=keep_nonorm(rho12,2,d);
FF=[rhoA==rho]+[rhoB==sigma]+[rho12>=0]+[trace(rho12)==1];

C=reordermat([1 2],d);
ops = sdpsettings('solver','mosek','verbose',0,'debug',1);
diagnostic=solvesdp(FF,-real(trace(rho12*C)),ops);
optimum=double(real(trace(rho12*C)));

coupling=double(rho12);
