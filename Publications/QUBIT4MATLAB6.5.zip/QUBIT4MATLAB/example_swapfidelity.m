% example_swapfidelity   swapfidelit_ppt is never smaller then swapfidelity 

clear all
close all
format compact

d=2;

rho=rdmat(1,d);
sigma=rdmat(1,d);

Fs=swapfidelity(rho,sigma)

Fs_ppt=swapfidelity_ppt(rho,sigma)


