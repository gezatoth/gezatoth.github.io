% example_fully_connected_spin_chain   Example for using 
%    optspinsq and optsudsq. It reproduces Table 1 in
%    https://arxiv.org/abs/2406.13338
%
% Table 1: 
% Limit temperatures 
%    for the su(d)-squeezing parameter given in Eq. (63), 
%    the spin-squeezing parameterin Eq. (124) and 
%    the PPT criterion 
% for various various particle numbers for the thermal states of 
% the Hamiltonian given in Eq. (125) for d = 3. 
% The limit temperature is the temperature above which 
% these criteria stop detecting entanglement. 
% The PPT criterion detects entanglement 
% if any of the bipartitions is not PPT.

clear all
close all
format compact

%%%%%%% INPUT PARAMETERS %%%%

% Set number of particles
N=6;

% Set parameter gamma
gamma_const=0;

% Set initial lower and upper bound
TL0=0;
TH0=12;

% Set resolution
DeltaT0=0.00000001;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Particle dimension
d=3;

g=sud(d);
% Note: trace(g(:,:,1)*g(:,:,1))=2

% Hamiltonian
H=coll(g(:,:,1),N)^2;
for n=2:8
    H=H+coll(g(:,:,n),N)^2;
end
H=H/N;

%%%%%%%% SU(d) criterion %%%%%%

TL=TL0;
TH=TH0;
DeltaT=DeltaT0;

while (TH-TL)>DeltaT,

    T=(TH+TL)/2;

    rho=thstate(H,T);

    criterion_with_variances=optsudsq(rho,d);

    if criterion_with_variances<0
        TL=T;
    else
        TH=T;
    end

end

% Print out the result 1
temperature_sud=(TH+TL)/2

%%%%%% SU(2) criterion %%%%%%

TL=TL0;
TH=TH0;
DeltaT=DeltaT0;

[jx,jy,jz]=su2(d);

Jx=coll(jx,N);
Jy=coll(jy,N);
Jz=coll(jz,N);

while (TH-TL)>DeltaT,

    T=(TH+TL)/2;

    rho=thstate(H,T);

    criterion_with_variances=optspinsq(rho,d);

    if criterion_with_variances<0
        TL=T;
    else
        TH=T;
    end

end

% Print out the result 2
temperature_spin=(TH+TL)/2

%%%%%% PPT criterion %%%%%%

TL=0;
TH=12;
DeltaT=0.00001;

I=N:-1:1;

while (TH-TL)>DeltaT,

    T=(TH+TL)/2;

    rho=thstate(H,T);

    % Generate all bipartite
    % partial tranposes
    c=0;
    for n=1:2^(N-1)-1
        b=dec2bin(n,N);
        a=(b=='1');
        I1=I(a);
        rhoTn=pt(rho,I1,d);
        c=min(c,mineig(rhoTn));
    end

    if c<0
        TL=T;
    else
        TH=T;
    end

end

% Print out the result 3
temperature_PPT=(TH+TL)/2



