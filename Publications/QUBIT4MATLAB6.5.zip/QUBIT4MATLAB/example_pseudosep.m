% example_pseudosep_state3x3   Eample how to use pseudosep_state3x3

clear all
close all
format compact

rho=pseudosep_state3x3 

density_matrix_eigenvalues=eig(rho)

neg=negativity(rho,2,3)

computable_cross_norm_realignment=ccnr(rho)

optimal_sud_squeezing=optsudsq(rho,3)

% Saturates the su(d) squeezing inequalities!
su3
sum_of_variances=va(coll(m1,2),rho)+va(coll(m2,2),rho)+va(coll(m3,2),rho)...
    +va(coll(m4,2),rho)+va(coll(m5,2),rho)+va(coll(m6,2),rho)...
    +va(coll(m7,2),rho)+va(coll(m8,2),rho)

N=2;
d=3;
bound=2*N*(d-1)

% Negative if detected as entangled.
% The state saturates the inequality
criterion=sum_of_variances-2*N*(d-1)

