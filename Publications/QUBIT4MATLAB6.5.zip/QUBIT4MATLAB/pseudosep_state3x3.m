% pseudosep_state3x3   A pseudoseparable state in 3x3 system.
%                      
% The state can be written as similarly to separable states as
% sum_k p_k rho_k^(1) otimes rho_k^(2), where trace[(rho_k^(n))^2]=1,
% however rho_k^(n)>=0 is not required. Thus, such states can be entangled.
% The state does not violate the CCNR criterion, however, it
% violates the PPT criterion. See
% G. Vitagliano, O. Gühne and G. Tóth, 
% su(d)-squeezing and many-body entanglement geometry 
% in finite-dimensional systems, 
% https://arxiv.org/abs/2406.13338

function rho=pseudosep_state3x3

N=2;
d=3;
su3;
g={m1,m2,m3,m4,m5,m6,m7,m8};
rho=zeros(d^2,d^2);
for n=1:8
    r=mmstate(1,d)+g{n}/sqrt(3);
    % shouldbe1=trace(r^2)

    r2=mmstate(1,d)-g{n}/sqrt(3);
    % shouldbe1=trace(r2^2)

    rho=rho+kron(r,r2)+kron(r2,r);
end
rho=rho/16;

