% ver   Prints out version.

disp(['MATLAB routines for Quantum Mechanics QUBIT4MATLAB V 5.8']) 
disp(['Geza Toth, 2005-2021'])