% U_H   2x2 unitary matrix realizing a Hadamard gate
function U=U_H

U=[1 1;1 -1]/sqrt(2);