% optspinsq(rho)   Optimal spin squeezing inequalities
%    optspinsq(rho) gives back a negative value if the
%    multi-qubit state rho is detected as entangled
%    by the optimal spin squeezing inequalities.
%    (See Eq. (2.b,c,d) http://arxiv.org/abs/quant-ph/0702219.
%     Eq. (2.a) is not included since it is satisfied by any quantum state.)
%    The form [fmin,f123]=optspinsq(rho) gives back
%    in f123 a three element array. Each element of the
%    array gives -1 times the violation of the corresponding spin
%    squeezing inequality. fmin is the minimum of the three values.
%    If one of them is negative then the state is detected as entangled.
%    Beside the inequalities themselves, a method is also
%    implemented that looks for the optimal choice of x, y, and z
%    coordinates (See fourth page of paper above).
%    optspinsq(rho,d) works for systems of qudits of dimension d,
%    see https://arxiv.org/abs/1310.2269.

function [fmin,f123,gm,X,Q,C]=optspinsq(rho,varargin)

if isempty(varargin),
    d=2;
else
    if length(varargin)~=1,
        error('Wrong number of input arguments.');
    end %if
    d=varargin{1};
end %if

if d==2
    
    [sy,sx]=size(rho);
    N=log2(sx);
    
    % Collective observables
    paulixyz;
    Jx=coll(x,N); % Here I did not use the 1/2!
    Jy=coll(y,N);
    Jz=coll(z,N);
    
    % Correlation matrix
    Cxx=trace(rho*Jx*Jx);
    Cyy=trace(rho*Jy*Jy);
    Czz=trace(rho*Jz*Jz);
    Cxy=trace(rho*(Jx*Jy+Jy*Jx)/2);
    Cxz=trace(rho*(Jx*Jz+Jz*Jx)/2);
    Cyz=trace(rho*(Jy*Jz+Jz*Jy)/2);
    C=[Cxx Cxy Cxz;Cxy Cyy Cyz; Cxz Cyz Czz];
    
    % Covariance matrix
    v=[trace(Jx*rho) trace(Jy*rho) trace(Jz*rho)];
    gm=C-v.'*v;
    
    X=(N-1)*gm+C;
    % /4 is needed since the definition of Jx (Jx=coll(x,N)) did not include a
    % factor of 1/2
    f123=[trace(gm)-2*N,mineig(X)-trace(C)+2*N,(N-1)*trace(gm)-N*(N-2)-maxeig(X)]/4;
    fmin=min(real(f123));
    Q=zeros(3,3);
    
else
    
    j=(d-1)/2;
    
    [sy,sx]=size(rho);
    N=floor(log2(sx)/log2(d)+0.5);
    
    % Collective observables
    [jx,jy,jz]=su2(d);
    Jx=coll(jx,N);
    Jy=coll(jy,N);
    Jz=coll(jz,N);
    
    % Correlation matrix
    Cxx=trace(rho*Jx*Jx);
    Cyy=trace(rho*Jy*Jy);
    Czz=trace(rho*Jz*Jz);
    Cxy=trace(rho*(Jx*Jy+Jy*Jx)/2);
    Cxz=trace(rho*(Jx*Jz+Jz*Jx)/2);
    Cyz=trace(rho*(Jy*Jz+Jz*Jy)/2);
    C=[Cxx Cxy Cxz;Cxy Cyy Cyz; Cxz Cyz Czz];
    
    % Q matrix relevant for j>1/2
    Q0=j*(j+1)/3;
    Q=zeros(3,3);
    jarray={jx,jy,jz};
    for k=1:3
        for l=1:3
            for n=1:N
                jk=jarray{k};
                jl=jarray{l};
                Q(k,l)=Q(k,l)...
                    +ex(quditop(jk,n,N)*quditop(jl,n,N)+quditop(jl,n,N)*quditop(jk,n,N),rho)/(2*N);
                if k==l
                    Q(k,l)=Q(k,l)-Q0/N;
                end
            end
        end
    end
    
    % Covariance matrix
    v=[trace(Jx*rho) trace(Jy*rho) trace(Jz*rho)];
    gm=C-v.'*v;
    
    X=(N-1)*gm+C-N^2*Q;
        
    f123=[trace(gm)-N*j,mineig(X)-trace(C)+N*j*(N*j+1)-N^2*Q0,(N-1)*trace(gm)-N*(N-1)*j+N^2*Q0-maxeig(X)];
    fmin=min(real(f123));
    
end



