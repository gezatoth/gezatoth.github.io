% Test new routines and compare them to old versions

clear all
format compact

%
% fisher.m
%
Nit=100;
for n=1:Nit
    
    d=randi(10,1);
    r=rdmat(1,d);
    A=rdmat(1,d);
    B=rdmat(1,d);
    
    if norm(fisher(r,A)-fisher_V_5_5(r,A))>1e-14
        error('Error')
    end
    
    if norm(fisher(r,A,B)-fisher_V_5_5(r,A,B))>1e-14
        error('Error')
    end
    
end

% Not full rank
for n=1:Nit
    
    d=randi(10,1);
    d2=d-randi(d,1);
    r=blkdiag(rdmat(1,d2),zeros(d-d2,d-d2));
    A=rdmat(1,d);
    B=rdmat(1,d);
    
    if norm(fisher(r,A)-fisher_V_5_5(r,A))>1e-14
        error('Error')
    end
    
    if norm(fisher(r,A,B)-fisher_V_5_5(r,A,B))>1e-14
        error('Error')
    end
    
end

% Compare run times
d=4;
r=rdmat(1,d);
A=rdmat(1,d);
tic
for n=1:Nit   
    fisher(r,A);
end
toc_fisher=toc
tic
for n=1:Nit   
    fisher_V_5_5(r,A);
end
toc_fisher_V_5_5=toc
ratio_of_execution_times=toc_fisher_V_5_5/toc_fisher