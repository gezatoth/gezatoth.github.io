QUBIT4MATLAB :

MATLAB PACKAGE FOR QUANTUM INFORMATION/
QUANTUM MECHANICS BY GEZA TOTH

This program package helps modelling spin chains,
qubit registers, etc. according to non-relativistic
quantum mechanics and some novel ideas from quantum
information theory.

In particular, it contains MATLAB routines
for reordering qubits, for computing
the reduced density matrix after removing
some of the qubits, for partial transposition, etc.
Most of the routines work also for qudits.
It also has routines for handling GHZ states,
cluster states, graph states, Dicke states, etc.

For the list of functions write

         help contents

For examples see

         example1
         example2
         example3.

---------------

History of versions:

QM versions:

V1.0         12 Apr  2005

V1.1         14 June 2005

keep/remove: bug corrected
new functions for qudits
new functions for spin chains

Name changed to QUBIT4MATLAB:

QUBIT4MATLAB V1.0    1 Sept 2005
nm:          bug corrected

QUBIT4MATLAB V1.1   23 Sept 2005
example1/2/3 added
addnoise:    added
negativity:  added
ising_free:  small bug corrected

QUBIT4MATLAB V1.2   26 Jan 2006
mineig:      added
maxeig:      added
spmqubitop:  name changed to mqubitopsp
printv:      bug corrected (did not work correctly for complex
             coefficients.)
qrvec:       added
qrproduct    added
interact     added
interactsp   added
twirl,twirl2 small bug corrected (the description did not fit
             what the routine was doing)

QUBIT4MATLAB V2.0   02 Oct 2006
qrvec             name changed to rvec
qrproduct         name changed to qrproduct
runitary          added
rdmat             added

grstate           added
thstate           added

ising             added
isingp            added
spising           added
spisingp          added
heisenberg        added
heisenbergp       added
spnnchain         added
spnnchainp        added
coll              added
spcoll            added
ising_classical_ground  added
xy_classical_ground     added

bra               added
ket               added
braket            added
ex                added

swapquidts        added
shiftquditsleft   added
shiftquditsright  added
reordervec        added
reorder           more efficient with large state vectors 
                  (>10 qubits); can use sparse matrices;
                  does not use base2dec for counting but
                  uses a faster method.
spreordermat      added
keep              Before keep(rho,[1 2]) and keep(rho,[2 1]) 
                  gave the same result. Now they give results
                  which are permutations of each other.
                  (qubit 1 and qubit 2 are exchanged)

decompose         faster since does not use base2dec for counting

twirl             works for qudits
twirl2            works for qudits

quditop           added
spquditop         added
twoquditop        added
sptwoquditop      added

printv            treshold can be given as a second parameter
mestate           added
mqubitop          removed: obsolete; use quditop and twoquditop

U_CNOT            added
U_H               added    