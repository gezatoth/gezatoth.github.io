% trace2   Trace-square of a matrix.

function t=trace2(rho)
   t=trace(rho^2);
