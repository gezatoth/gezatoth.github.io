% wdistsquare   Wasserstein distance square
%    Obtained via a minimization over quantum states.
%    Parameters: wdistsquare(rho,sigma,H), where
%    rho are sigma are density matrices, H is an operator.
%    It can give additional parameters:
%    [distance,diagnostic,coupling]=wdistsquare(rho,sigma,H)
%    Here, coupling is the bipartite state corresponding
%    to the minimum of the ioptmization problem.
%    diagnostic is a variable from solvesdp in YALMIP.
%    See https://arxiv.org/abs/2209.09925

function [optimum,diagnostic,coupling]=wdistsquare(rho,sigma,H)

% 0-General quantum states, 1-PPT states
PPT_STATES_ON=0;

% 0-No transpose, 1-Transpose
TRANSPOSE_ON=0;

% 0-MIN,1-MAX
MIN_OR_MAX=0;

[sy,sx]=size(rho);

d=sx;
d1=d;
d2=d;

E1=eye(d1,d1);
E2=eye(d2,d2);

rho12=sdpvar(d1*d2,d1*d2,'hermitian','complex');
rhoA=keep_nonorm(rho12,1,d);
rhoB=keep_nonorm(rho12,2,d);
FF=[rho12>=0]+[trace(rho12)==1];

if TRANSPOSE_ON==0,
    M=(kron(E2,H)-kron(H,E1))^2; % Note: no patial transpose!
    FF=FF+[rhoA==sigma]+[rhoB==rho];
else
    M=(kron(E2,H)-kron(H.',E1))^2; % Note: with patial transpose!
    FF=FF+[rhoA==sigma]+[rhoB==rho.'];
end

if PPT_STATES_ON==1,
   FF=FF+[pt_nonorm(rho12,1,d1)>=0];
end

ops = sdpsettings('solver','mosek','verbose',0,'debug',1);
if MIN_OR_MAX==1
   diagnostic=solvesdp(FF,-real(trace(rho12*M)),ops);
else
   diagnostic=solvesdp(FF,real(trace(rho12*M)),ops);
end

optimum=1/2*double(trace(rho12*M));

coupling=double(rho12);
