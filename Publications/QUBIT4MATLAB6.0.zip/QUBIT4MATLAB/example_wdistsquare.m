% example_wdistsquare   Example for using the Wasserstein distance
%                       routines.

clear all
close all
format compact

d=2;
rho=rdmat(1,d);
sigma=rdmat(1,d);

H=diag([1;-1]);

wdistsquare_rho_sigma=wdistsquare(rho,sigma,H)

wdistsquare_GMPC_rho_sigma=wdistsquare_GMPC(rho,sigma,H)

wdistsquare_GMPC_ppt_rho_sigma=wdistsquare_GMPC_ppt(rho,sigma,H)

wdistsquare_ppt_rho_sigma=wdistsquare_ppt(rho,sigma,H)

wdistsquare_ppt_rho_sigma=wdistsquare_ppt(rho,sigma,H)

wvar_rho_sigma=wvar(rho,sigma,H)

wvar_GMPC_rho_sigma=wvar_GMPC(rho,sigma,H)

wvar_GMPC_ppt_rho_sigma=wvar_GMPC_ppt(rho,sigma,H)

wvar_ppt_rho_sigma=wvar_ppt(rho,sigma,H)


