% twirl   Twirling
%   twirl(rho) twirls the multi-qubit density matrix rho.
%   [rho,difference]=twirl(rho) also gives the 
%   norm of the difference between the original and the 
%   twirled state. The difference is computed through the norm 
%   ||A||=sum_kl |A_kl|^2. Obvoiusly, the difference is zero
%   for Werner states. The form twirl(rho,Nit)
%   makes it possible to determine how many random
%   unitaries are used for twirling. (The algorithm
%   is not the straightforward integration of
%   the integral in the formula for twirling.)
%   The default value for Nit is 100.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function [r,difference]=twirl(rho,varargin);

if length(varargin)==0,
   % Number of random unitaries used
   Nit=100;
elseif length(varargin)==1,
   Nit=varargin{1};
else
   error('Wrong number of input arguments');
end %if
   
x=[0 1;1 0];
z=[1 0;0 -1];
y=i*x*z;

[sy,sx]=size(rho);
N=log2(sx); 

% Fact algorithm
r=rho;
U=eye(2);
for n=1:Nit     
    if mod(n,100)==0,  rand('state',sum(100*clock));  end %if
    U=U*expm(i*rand(1,1)*4*pi*x)*expm(i*rand(1,1)*4*pi*z);
    UU=U;
    for n=2:N
        UU=kron(UU,U);   
    end %for
    r=r+UU*r*UU';
end %for
r=r/trace(r);

difference=trace((r-rho)*(r-rho)');


