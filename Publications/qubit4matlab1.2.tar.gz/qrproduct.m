% qrproduct   Random product state vector for a given number of qubits.
%   qrproduct(n) gives an n-qubit product of random single-qubit state vectors.
%   The distribution of single-qubit state vectors obtained this way
%   is uniform over the sphere of unit vectors. If N
%   is not given then it is taken to be equal to the global
%   variable N.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function p=qrproduct(varargin)

if isempty(varargin),
    global N;
else
    if length(varargin)~=1,
        error('Wrong number of input arguments.')
    end %if
    N=varargin{1};
end %if

% Before normalization, elements of the vector 
% have a normal distribution.
p=randn(2,1)+i*randn(2,1);
p=p/sqrt(p'*p);

for n=1:N-1
   s=randn(2,1)+i*randn(2,1);
   s=s/sqrt(s'*s);
   p=kron(p,s);
end %for
