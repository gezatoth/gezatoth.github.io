% binom   binom(m,n) is factorial(n)/factorial(n-m)/factorial(m)

function c=binom(a,b)

c=factorial(a)/factorial(a-b)/factorial(b);


