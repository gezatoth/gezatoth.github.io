% realign   Realignment of the bipartite density matrix.
%    realign(rho,d1,d2) relignes the density matrix rho
%    in a bipartite systems where the two parties have dimensions
%    d1 and d2, respectively. 
%    Realizes a linear map such that
%      realign(|i><j| kron |k><l|)=
%              |i><k| kron |j><l|.
%    For more details see 
%    O. Rudoplh, Phys. Rev. A 67, 032312 (2003).

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function rhoR=realign(rho,d1,d2)

f1=cell(d1,1);
for n=1:d1
   v=zeros(d1,1);
   v(n)=1;
   f1{n}=v;
end %for

f2=cell(d2,1);
for n=1:d2
   v=zeros(d2,1);
   v(n)=1;
   f2{n}=v;
end %for

for i1=1:d1
    for j1=1:d1
        for i2=1:d2
            for j2=1:d2
                op=kron(f1{i1}*(f1{j1}).',f2{i2}*(f2{j2}).');
                r(i1,j1,i2,j2)=trace(rho*op);
            end %for
        end %for
    end %for
end %for

rhoR=zeros(d1*d1,d2*d2);
for i1=1:d1
    for j1=1:d1
        for i2=1:d2
            for j2=1:d2
                op=kron(f1{i1}*(f1{j1}).',f2{i2}*(f2{j2}).');
                rhoR=rhoR+trace(rho*op)*kron(f1{i1}*(f2{i2}).',f1{j1}*(f2{j2}).');
            end %for
        end %for
    end %for
end %for
