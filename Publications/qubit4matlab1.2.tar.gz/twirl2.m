% twirl2   How much a state changes under unitaries of the form mkron(U,U,U,...)
%   twirl2(rho) gives the maximal difference between the original state,
%   rho and the state obtained from it by a unitary of the form
%   mkron(U,U,U,...), where U is a single qubit unitary.
%   The difference is computed through the norm 
%   ||A||=sum_kl |A_kl|^2. Obvoiusly, the difference 
%   is zero for Werner states. The form twirl2(rho,Nit)
%   makes it possible to determine how many random
%   unitaries are used for the search. The default value for Nit is 100.
%   The form  [difference,U0]=twirl2(rho) gives also back
%   the unitary U0 for which the largest the difference is
%   between the original and the rotated state.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function [difference,U0]=twirl2(rho,varargin);

if length(varargin)==0,
   % Number of random unitaries used
   Nit=100;
elseif length(varargin)==1,
   Nit=varargin{1};
else
   error('Wrong number of input arguments');
end %if
   
x=[0 1;1 0];
z=[1 0;0 -1];
y=i*x*z;

[sy,sx]=size(rho);
N=log2(sx); 

r=0;
difference=0;
for n=1:Nit     
    if mod(n,100)==0,  rand('state',sum(100*clock));  end %if
    phi=rand(1,1)*4*pi;
    theta=rand(1,1)*4*pi;
    U=expm(i*phi*x)*expm(i*theta*z);
    UU=U;
    for n=2:N
        UU=kron(UU,U);   
    end %for
    r=UU*rho*UU';
    % real is important since MATLAB gives results with small
    % imaginary part; this spoils the use of > and <
    d=real(trace((r-rho)*(r-rho)'));
    if d>difference,
        difference=d;
        U0=U;
    end %if
end %for





