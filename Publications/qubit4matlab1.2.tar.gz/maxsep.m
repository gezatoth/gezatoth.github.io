% maxsep   Maximum for multi-qubit separable states. 
%   Uses simple numerical search for which parameters can 
%   be set in the beginning of the maxsep.m file. 
%   Slower than maxsymsep.


function m=maxsep(op)

[sx,sy]=size(op);
N=log2(sx);

% Parameters for the simulation
Delta=0.005;
Nit1=10000;
Nit2=20000;

rmax=-Inf;

% Dimensions
d=2;

fa=zeros(d,N);
famax=fa;
for n=1:Nit1
     if mod(n,100)==0,  randn('state',sum(100*clock));  end %if
     f=(rand(d,1)-0.5)+i*(rand(d,1)-0.5);
     fa(:,1)=f;
     for n=1:N-1
        f2=(rand(d,1)-0.5)+i*(rand(d,1)-0.5);
	fa(:,n+1)=f2;
        f=kron(f,f2);
     end %for
     r=real(trace(op*f*f')/(f'*f));
     if r>rmax,
         rmax=r;
	 famax=fa;
     end %if
end %for


fa0=famax;
r0=rmax;

% Second phase of the search
for n=1:Nit2
     if mod(n,100)==0,  randn('state',sum(100*clock));  end %if
     f=(rand(d,1)-0.5)+i*(rand(d,1)-0.5);
     f=fa0(:,1)+Delta*f;
     fa(:,1)=f;
     for n=1:N-1
        f2=(rand(d,1)-0.5)+i*(rand(d,1)-0.5);
	f2=fa0(:,n+1)+Delta*f2;
	fa(:,n+1)=f2;
        f=kron(f,f2);
     end %for
     r=real(trace(op*f*f')/(f'*f));
     if r>r0,
         r0=r;
         fa0=fa;        
     end %if
end %for
 
m=r0;

