QUBIT4MATLAB :

MATLAB PACKAGE FOR QUANTUM INFORMATION/
QUANTUM MECHANICS BY GEZA TOTH

This program package helps modelling spin chains,
qubit registers, etc. according to non-relativistic
quantum mechanics and some novel ideas from quantum
information theory.

In particular, it contains MATLAB routines
for reordering qubits, for computing
the reduced density matrix after removing
some of the qubits, for partial transposition, etc.
Most of the routines work also for qudits.
It also has routines for handling GHZ states,
cluster states, graph states, Dicke states, etc.

For the list of functions write

         help contents

For examples see

         example1
         example2
         example3.

---------------

History of versions:

QM versions:

V1.0         12 Apr  2005

V1.1         14 June 2005

keep/remove: bug corrected
new functions for qudits
new functions for spin chains

Name changed to QUBIT4MATLAB:

QUBIT4MATLAB V1.0    1 Sept 2005
nm:          bug corrected

QUBIT4MATLAB V1.1   23 Sept 2005
example1/2/3 added
addnoise:    added
negativity:  added
ising_free:  small bug corrected

QUBIT4MATLAB V1.2
mineig:      added
maxeig:      added
spmqubitop:  name changed to mqubitopsp
printv:      bug corrected (did not work correctly for complex
             coefficients.)
qrvec:       added
qrproduct    added
interact     added
interactsp   added
twirl,twirl2 small bug corrected (the description did not fit
             what the routine was doing)
