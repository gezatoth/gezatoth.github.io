% addnoise   Adds white noise to a denisty matrix.
%   addnoise(rho,p,d) computes the matrix 
%   rho'=(1-p)*rho+p*eye(d^N)/d^N where N is
%   the number of qudits and d is the dimension of
%   the qudts. If rho is a state vector then 
%   its is converted into a normalized density matrix.
%   If parameter d is omitted then it 
%   is taken to be 2 (qubits).

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function rho_noisy=addnoise(rho,p,varargin)

if isempty(varargin),
   d=2;
else
    if length(varargin)~=1,
        error('Wrong number of input arguments.');
    end %if
    d=varargin{1};
end %if

% Convert state vector to density matrix if necessary
rho=ketbra2(rho);

% Obtain teh size of the density matrix
[sx,sy]=size(rho);
N=log2(sx)/log2(d);
N=floor(N+0.5);

rho_noisy=(1-p)*rho+p*eye(2^N)/2^N;