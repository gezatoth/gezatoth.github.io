% mqubitopsp   Operator on given qubit, sparse version.
%   qubitopsp(op,k,n) defines an n-qubit quantum operator
%   which corresponds to operator op acting on the kth qubit.
%   Qubit position is interpreted according to mkron(q1,q2,q3,...).
%   op can also be multi-qubit operation. If n is omitted,
%   the its value is taken to be the value of global
%   variable N.

% Copyright (C) 2005  Geza Toth    E.mail: toth@alumni.nd.edu
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; see gpl.txt
% of this subroutine package.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

function mop=mqubitopsp(op,index,varargin)
if isempty(varargin),
    global N;
else
    if length(varargin)~=1,
        error('Wrong number of input arguments.')
    end %if
    N=varargin{1};
end %if

[sy,sx]=size(op);
N2=log2(sx);

mop=kron(speye(2^(index-1)),op);
mop=kron(mop,speye(2^(N-index-N2+1)));
