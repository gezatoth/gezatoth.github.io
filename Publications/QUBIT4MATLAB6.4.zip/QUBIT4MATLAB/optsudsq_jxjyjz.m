% optsudsq_jxjyjz(rho)   Optimal su(d) squeezing inequalities
%    optsudsq_jxjyjz(rho) gives back a negative value if the
%    multi-qubit state rho is detected as entangled
%    by the optimal su(d) squeezing inequalities
%    for d=3 such that the first three su(d) generators are jx,jy,jz
%    angular momentum operators.
%    The form [fmin,gm,U,Q,C]=optsudsq_jxjyjz(rho) gives back
%    Beside the inequalities themselves, a method is also
%    implemented that looks for the optimal choice of 
%    su(d) generators.
%    [fmin,gm,U,Q,C]=optsudsq_jxjyjz(rho) gives back also
%    the fmin,U,Q,C matrices.
%    See https://arxiv.org/abs/2406.13338

function [fmin,gm,U,Q]=optsudsq_jxjyjz(rho)

d=3;
j=(d-1)/2;

[sy,sx]=size(rho);
N=floor(log2(sx)/log2(d)+0.5);

%g=sud(d);
% Note: trace(g(:,:,1)*g(:,:,1))=2

% su(d) generators
su3_alternative2
g(:,:,1)=m1;
g(:,:,2)=m2;
g(:,:,3)=m3;
g(:,:,4)=m4;
g(:,:,5)=m5;
g(:,:,6)=m6;
g(:,:,7)=m7;
g(:,:,8)=m8;

Gk=zeros(d^N,d^N,d^2-1);
sumvar=0;
for k=1:d^2-1
    gk=g(:,:,k);
    Gk(:,:,k)=coll(gk,N);
end

% Correlation matrix
C=zeros(d^2-1,d^2-1);
gm=zeros(d^2-1,d^2-1); % gamma
Q=zeros(d^2-1,d^2-1);
for k=1:d^2-1
    for l=1:d^2-1
        C(k,l)=ex(Gk(:,:,k)*Gk(:,:,l)+Gk(:,:,l)*Gk(:,:,k),rho)/2;
        gm(k,l)=C(k,l)-ex(Gk(:,:,k),rho)*ex(Gk(:,:,l),rho);
        Q_temp=0;
        for n=1:N
            Q_temp=Q_temp...
                +ex(quditop(g(:,:,k),n,N)*quditop(g(:,:,l),n,N)...
                   +quditop(g(:,:,l),n,N)*quditop(g(:,:,k),n,N),rho)/2;
        end
        Q(k,l)=Q_temp/N;
    end
end
Q0=2*(d^2-1)/d;
Q=Q-Q0*eye(d^2-1,d^2-1);

U=gm+C/(N-1)-N^2/(N-1)*(Q+Q0*eye(d^2-1,d^2-1));

% X=(N-1)*gm+C-N^2*Q;

eigU=eig(U);

fmin=trace(gm)-sum(eigU.*(eigU>0))-2*N*(d-1);