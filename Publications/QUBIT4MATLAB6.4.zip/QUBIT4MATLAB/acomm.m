%acomm Anticommutator of two matrices.
%   acomm(A,B)=AB+BA gives the anticommutator of A and B.

function a=acomm(A,B)
a=A*B+B*A;