% coll_multicopy  Defines a collective operator which is the sum of single-qudit operators.
%   coll_multicopy(op,n,1) defines an operator of the type sum_k op(k) where
%   op(k) denotes the operator op acting on qubit k.
%   coll_multicopy(op,n,m) does the same for m copies for correlation
%   operators acting on all copies.
%   If argument n is omitted than the default is taking to be
%   the value of global variable N. The size of op determines
%   whether we talk about qubits, qudits, etc.

function c=coll_multicopy(op,N,number_of_copies)

% Dimension (d=2 for qubits, d=3 for qutrits, etc.)
d=max(size(op));

c=zeros(d^(N*number_of_copies));
for n=1:N
    c=c+pkron(kron(kron(eye(d^(n-1)),op),eye(d^(N-n))),number_of_copies);
end %for
