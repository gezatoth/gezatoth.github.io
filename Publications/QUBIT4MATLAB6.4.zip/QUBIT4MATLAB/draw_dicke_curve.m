% draw_dicke_curves   The program draws the line corresponding to 
%                     k-entagled states in the 
%                     ((\Delta J_z)^2/(Nj),(<Jx^2+Jy^2)/(Nj)/(Nj+1)>)-plane 
%                     This is relevant for experiments carried out with
%                     Dicke states.

% The method works even if N is diviseble by k
% G. Vitagliano, I. Apellaniz, M. Kleinmann, B. Lücke, C. Klempt, and G. Tóth, 
% Entanglement and extreme spin squeezing of unpolarized states, 
% New J. Phys. 19, 013027 (2017)
% https://arxiv.org/abs/1605.07202
% https://doi.org/10.1088/1367-2630/19/1/013027

% It uses the package QUBIT4MATLAB
% https://www.gtoth.eu/qubit4matlab.html
% https://es.mathworks.com/matlabcentral/fileexchange/8433-qubit4matlab

clear all
close all
format compact

% Particle number
N=12000;
% Entangklement depth k
% k must be even, if j is not an integer
k=600;
% Particle spin
j=1;
% integer j, or even k for half integer j 
J=k*j;

% Parameter range scanned
% For large values, the points do not
% have to be dense
%lambdaR=[0.001:0.01:40,40.1:5:3000];
%lambdaR=[0.001:0.1:40,40.1:10:3000];
lambdaR=exp(-7:0.1:7);

% Creates the Jx, Jy, Jz angular momentum operators as SU(2) generators 
[Jx,Jy,Jz]=su2(2*J+1);

% Arrays storing the results for the two methods
% They store <Jx^2+Jy^2> for the trial state
ex_Jx2plusJx2=[];
va_Jz=[];
for lambda=lambdaR
   % We look for the ground state of the following Hamiltonian
   H=Jz^2-lambda*Jx;
   % Obtain the ground state
   f=grstate(H);

   % Store the value of <Jx^2+Jy^2>
   ex_Jx2plusJx2=[ex_Jx2plusJx2,N*(N-k)*j^2/k^2/j^2*ex(Jx,f)^2+N*j*(k*j+1)];

   % Store the value of (Delta Jz)^2
   va_Jz=[va_Jz,N/k*va(Jz,f)];
end

% Draw the figure
plot(ex_Jx2plusJx2/(N*j)/(N*j+1),va_Jz/N/j,'b-','LineWidth',2)

xlabel('$\langle J_x^2+J_y^2\rangle/(Nj)/(Nj+1)$','Interpreter','LaTeX','FontSize',16)
ylabel('$(\Delta J_z)^2/(Nj)$','Interpreter','LaTeX','FontSize',16)
