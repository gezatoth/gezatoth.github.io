% ver   Prints out version.

disp(['MATLAB routines for Quantum Mechanics QUBIT4MATLAB V 5.5']) 
disp(['Geza Toth, 2005-2016'])